
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'elotgamu',
  applicationName: 'lambda-challenge-serverless',
  appUid: 'nRhtRbMSTtJtw2GkkK',
  orgUid: '6d894805-de5f-4918-9fbd-7a819d0adca7',
  deploymentUid: '8a4e56d5-b542-43da-a561-e324e0d67d30',
  serviceName: 'lambda-challenge',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '4.4.2',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'lambda-challenge-dev-message', timeout: 6 };

try {
  const userHandler = require('./src/message.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}