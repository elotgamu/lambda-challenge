// lambda-like handler function
module.exports.handler = async (event) => {
  // do stuff...
};
